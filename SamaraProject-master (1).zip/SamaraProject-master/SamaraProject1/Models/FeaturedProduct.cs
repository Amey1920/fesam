﻿namespace SamaraProject1.Models
{
    public class FeaturedProduct
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string ImageUrl { get; set; }
    }
}
