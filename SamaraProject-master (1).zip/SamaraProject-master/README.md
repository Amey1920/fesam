# C# + Razor Web APP in .NET

Informative page with an administrative Database of the Samara Market

- [Deploy: https://samaraproject.onrender.com](https://samaraproject.onrender.com)

- Email: `idrhouse98@protonmail.com`
